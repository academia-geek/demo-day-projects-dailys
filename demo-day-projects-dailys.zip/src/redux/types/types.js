export const typesLogin = {
    login: 'login',
    logout: 'logout',
    register: 'register',
    add: 'add',
    list: 'list',
    edit: 'edit'
}
export const typesTask = {
    list: 'list',
    agregar: "agregar",
    edit: 'edit',
    delete: 'delete'
}
export const typesAlarm = {
    list: 'list',
    add: "add",
    edit: 'edit',
    delete: 'delete'
}
export const typesPerfil = {
    list: 'list',
    edit: 'edit',
}