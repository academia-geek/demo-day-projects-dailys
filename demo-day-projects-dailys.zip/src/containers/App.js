import WelcomePage from "../components/WelcomePage";

function App() {
  return (
    <div className="App">
       <WelcomePage/>
    </div>
  );
}
export default App;