import React from 'react'
import "../../styles/landing/stylesLanding.css"

const Comentarios = () => {
  return (
    <div className='coment'>
        <img  className='comillas' src='https://res.cloudinary.com/paolavbm/image/upload/v1647798621/cita_ekp7wh.png' width={50} alt='' />
        <h4>Qué dicen sobre Dailys</h4>
        <p>No sé como era mi vida antes de Dailys, excelente herramienta de organización. Una super ayuda, definitivamente lo que necesitaba, hace de tu vida una rutina más sencilla </p>
{/*       
      <div> <img src='https://res.cloudinary.com/paolavbm/image/upload/v1647798177/heart_ih6lfa.png' width={60} alt='' /> </div>  */}
       <div> <img src='https://res.cloudinary.com/paolavbm/image/upload/v1647806957/punto_mgsxev.png' width={60} alt='' /> </div>  
       <span>@patriciavalentina</span>
      
    </div>
  )
}

export default Comentarios