import React from 'react'
import {DivFooter, ImgLogo, DivCols, DivContCol, DivColumnFoo, DivFlex, ImgRedes} from  "../../styles/landing/styledLanding"
import "../../styles/landing/stylesLanding.css"

const Footer = () => {
    
  return (
   
            <div className='footer'>





            </div>
    
  )
}

export default Footer